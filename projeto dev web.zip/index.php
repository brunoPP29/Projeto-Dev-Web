<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../projeto de fato/estilo/style.css">
    <title>Site de fato nego</title>
</head>
<body>
    <header class="header1">
        <div class="container">
            <div class="logomarca">
                <h1><a href="index.php">LogoMarca</a></h1>
            </div>
            <div class="menu-desk">
                <nav class="nav-desktop">
                    <ul>
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="#">SOBRE</a></li>
                        <li><a href="#">CONTATO</a></li>
                    </ul>
                </nav>
            </div>
            <div class="clear"></div>
            <div class="menu-mob">
                <nav class="nav-mobile">
                    <ul>
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="#">SOBRE</a></li>
                        <li><a href="#">CONTATO</a></li>
                    </ul>
                </nav>
            </div>
            <div class="clear"></div>
        </header>

</div>

            <section class="cadastrar">
                <div class="overlay">.</div>
                <div class="container">
                    <div class="contCad">
                        <h1>Qual seu melhor E-mail?</h1>
                        <form>
                            <input id="emailtype" type="email" name="cadastroemail" placeholder=""/>
                            <input id="submitbutton" type="submit" name="cadastrosubmit" value="Cadastrar"/>
                        </form>
                    </div>
                </div>
            </section>
            <div class="clear"></div>

        </div>


        <section class="sobreDev">
            <div class="container">
                <div class="w50 left">
                    <div class="textDev">
                        <h2>Sobre o Dev</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero modi, recusandae rem velit beatae quod a quis, officiis expedita natus deleniti similique ut soluta saepe voluptatem maxime! Praesentium, quas quo.</p>
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptate quia velit obcaecati facilis eligendi repudiandae omnis qui veritatis nesciunt consequatur, accusamus, incidunt necessitatibus temporibus veniam possimus sapiente deleniti explicabo tempore.</p>
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptate quia velit obcaecati facilis eligendi repudiandae omnis qui veritatis nesciunt consequatur, accusamus, incidunt necessitatibus temporibus veniam possimus sapiente deleniti explicabo tempore.</p>
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptate quia velit obcaecati facilis eligendi repudiandae omnis qui veritatis nesciunt consequatur, accusamus, incidunt necessitatibus temporibus veniam possimus sapiente deleniti explicabo tempore.</p>
                    </div>
                </div>
                <div class="w50 right">
                    <div class="imgdev">
                        <img src="./images/DEV.jpg">
                    </div>                
                </div>
            </div>
            <div class="clear"></div>
        </section>

        <section class="especialidades">
                <div class="container">
                    <div class="espectext">
                        <h1>Especialidades</h1>
                    </div>
                    <div class="">
                        <div class="single-box">
                            <img src="https://img.icons8.com/?size=100&id=37927&format=png&color=000000">
                            <h2>Habilidade</h2>
                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Necessitatibus voluptates harum possimus architecto, nostrum aperiam impedit aspernatur illum reiciendis consequuntur voluptas, dolor velit repudiandae doloremque, neque maxime cupiditate adipisci expedita.</p>
                        </div>
                        <div class="single-box">
                            <img src="https://img.icons8.com/?size=100&id=37927&format=png&color=000000">
                            <h2>Habilidade</h2>
                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Necessitatibus voluptates harum possimus architecto, nostrum aperiam impedit aspernatur illum reiciendis consequuntur voluptas, dolor velit repudiandae doloremque, neque maxime cupiditate adipisci expedita.</p>
                        </div>
                        <div class="single-box">
                            <img src="https://img.icons8.com/?size=100&id=37927&format=png&color=000000">
                            <h2>Habilidade</h2>
                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Necessitatibus voluptates harum possimus architecto, nostrum aperiam impedit aspernatur illum reiciendis consequuntur voluptas, dolor velit repudiandae doloremque, neque maxime cupiditate adipisci expedita.</p>
                        </div>
                    </div>
                </div>
                <div class="clear"></div>
        </section>

</body>
</html>