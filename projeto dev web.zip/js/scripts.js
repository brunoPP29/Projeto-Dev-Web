$(function(){
    $('.nav-mobile #closeMenu').hide();

    $('.nav-mobile').click(function(){
        var listaMenu = $('.nav-mobile ul');
        if(listaMenu.is(':hidden') == true){
            var iconeMenu = $('#iconMenu').css('display','none');
            var iconeX = $('#closeMenu').css('display','block')
            listaMenu.fadeToggle();
        }else{
            var iconeMenu = $('#iconMenu').css('display','block');
            var iconeX = $('#closeMenu').css('display','none')
            listaMenu.fadeToggle();
        }
    })
})